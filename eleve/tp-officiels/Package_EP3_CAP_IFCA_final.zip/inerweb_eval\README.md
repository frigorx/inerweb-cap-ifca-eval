# inerWeb Eval EP3 — Outil d'évaluation multi-profs

**Version :** 1.0 — pour CAP IFCA 2 révisions EP3 · fin d'année 2026
**Auteur :** F. Henninot

---

## En une ligne

Un mini-serveur Node.js qui tourne sur un PC, accessible depuis 2 navigateurs (toi + ton collègue d'atelier) pour évaluer les 24 élèves sur les 6 TP EP3. Les données sont sauvegardées en dur dans `data/evaluations.json`, avec backups horaires automatiques.

---

## Prérequis

- **Node.js** installé (version ≥ 16)
  → https://nodejs.org — prendre la version **LTS**, installation défaut
- 2 PC sur le même réseau local (wifi classe, même box, même VLAN)
- Chrome, Edge ou Firefox à jour

---

## Démarrage en 4 étapes

### 1. Lancer le serveur (sur ton PC "maître")

Double-clic sur `LANCER.bat` → une fenêtre noire s'ouvre avec quelque chose comme :

```
  Ton PC         : http://localhost:3939
  Autre prof     : http://192.168.1.42:3939
```

Laisse cette fenêtre ouverte pendant toute la session. Ne la ferme pas.

### 2. Te connecter sur ton PC

Ouvre le navigateur sur `http://localhost:3939`. Tu arrives sur l'écran d'accueil.

### 3. Connecter le collègue

Sur son PC, il tape l'URL `http://192.168.1.42:3939` (remplace par l'IP affichée dans la fenêtre du serveur).

### 4. Choisir vos pseudos

Chacun tape son prénom / initiales à l'accueil (ex « FH » et « PW »). Les évaluations seront horodatées avec qui a fait quoi.

**C'est tout.** Les 2 profs voient les mêmes élèves, les mêmes TP, les mêmes évaluations. Les modifications sont synchronisées toutes les 3 secondes automatiquement.

---

## Fonctionnalités

- **24 élèves** avec noms éditables (1 fois suffit, persisté)
- **6 TP** (TP-050 à TP-055) avec critères d'évaluation EP3
- **Évaluation critère par critère** : 4 niveaux (Non acquis / En cours / Acquis / Maîtrisé)
- **Note /20 calculée automatiquement** par TP et par élève
- **Moyenne EP3 globale** par élève (6 TP pondérés)
- **Commentaires enseignant** par évaluation (observations libres)
- **Bulletin EP3 imprimable** par élève (Ctrl+P → Enregistrer en PDF)
- **Indicateur « Qui évalue quoi »** : si un prof est sur un élève, l'autre voit un bandeau
- **Stats classe en direct** : moyenne, distribution des notes, élèves à risque
- **Export JSON** (backup manuel ponctuel)
- **Backup horaire automatique** dans `data/backups/`

---

## Sauvegarde des données

- **Fichier principal** : `data/evaluations.json` — écrit à chaque modification
- **Backups horaires** : `data/backups/evaluations_YYYYMMDD_HH.json` — une copie par heure
- **Export manuel** : bouton « Exporter JSON » dans l'interface → téléchargement à la date

**Restauration** : si tu veux revenir à un état précédent, remplace `data/evaluations.json` par un backup (serveur à redémarrer après).

---

## Arrêt

Dans la fenêtre noire du serveur, Ctrl+C (ou ferme la fenêtre). Les données sont déjà sauvegardées — rien à faire de plus.

---

## Dépannage rapide

| Problème | Solution |
|---|---|
| `Node.js n'est pas installé` | Installer depuis https://nodejs.org (version LTS) |
| `Port 3939 déjà utilisé` | Fermer l'autre instance OU modifier `PORT` ligne 11 de `server.js` |
| Le collègue ne se connecte pas | Vérifier le pare-feu Windows (autoriser Node.js) + même réseau wifi |
| Les données ne se mettent pas à jour | Rafraîchir la page (F5). Le polling est à 3 s sinon. |
| J'ai perdu des évaluations | Voir `data/backups/` pour récupérer une version horaire |

---

## Structure du projet

```
inerweb_eval/
├── LANCER.bat          ← double-clic pour démarrer
├── server.js           ← serveur Node.js (< 150 lignes)
├── package.json
├── README.md           ← ce fichier
├── data/
│   ├── evaluations.json  ← la base
│   └── backups/          ← backups horaires auto
└── public/
    └── index.html      ← frontend complet (multi-vues, multi-profs)
```

---

## Pare-feu Windows

Au premier lancement, Windows peut demander d'autoriser Node.js à communiquer sur le réseau. **Cocher « Réseaux privés »** et valider. Sinon le collègue ne pourra pas se connecter.

Si tu as loupé l'invite : Panneau de config → Pare-feu → Autoriser une application → cocher Node.js pour les réseaux privés.

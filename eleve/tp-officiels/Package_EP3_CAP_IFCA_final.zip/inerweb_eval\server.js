// inerWeb Eval EP3 — mini-serveur Node.js multi-profs
// Usage : node server.js (ou double-clic sur LANCER.bat)
// Accessible depuis un autre PC : http://<IP locale>:3939

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = 3939;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const DATA_FILE = path.join(DATA_DIR, 'evaluations.json');
const PUBLIC_DIR = path.join(ROOT, 'public');

// Assure l'existence du dossier data
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(DATA_FILE, JSON.stringify({
    _meta: { created: new Date().toISOString(), version: '1.0' },
    statuts: {},
    eval: {},
    names: {},
    profils: {},
    commentairesGlobaux: {},
    historique: []
  }, null, 2), 'utf8');
}

// Backup horaire automatique
function backupData() {
  try {
    const now = new Date();
    const stamp = now.toISOString().slice(0, 13).replace(/[:-]/g, '').replace('T', '_');
    const backupDir = path.join(DATA_DIR, 'backups');
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
    const backupFile = path.join(backupDir, `evaluations_${stamp}.json`);
    if (!fs.existsSync(backupFile) && fs.existsSync(DATA_FILE)) {
      fs.copyFileSync(DATA_FILE, backupFile);
    }
  } catch (e) { /* silent */ }
}
setInterval(backupData, 3600 * 1000); // toutes les heures

// MIME types
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function sendJSON(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => { data += c; if (data.length > 5_000_000) { req.destroy(); reject(new Error('Too large')); } });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

function serveStatic(res, filePath) {
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('404 Not Found');
    }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': 'no-cache'
    });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = req.url.split('?')[0];

  // API
  if (url === '/api/state' && req.method === 'GET') {
    try {
      const content = fs.readFileSync(DATA_FILE, 'utf8');
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(content);
    } catch (e) { sendJSON(res, 500, { error: e.message }); }
    return;
  }

  if (url === '/api/state' && req.method === 'POST') {
    try {
      const body = await readBody(req);
      const parsed = JSON.parse(body);
      parsed._meta = parsed._meta || {};
      parsed._meta.lastUpdate = new Date().toISOString();
      fs.writeFileSync(DATA_FILE, JSON.stringify(parsed, null, 2), 'utf8');
      sendJSON(res, 200, { ok: true, ts: parsed._meta.lastUpdate });
    } catch (e) { sendJSON(res, 400, { error: e.message }); }
    return;
  }

  if (url === '/api/ping' && req.method === 'GET') {
    sendJSON(res, 200, { ok: true, ts: new Date().toISOString() });
    return;
  }

  if (url === '/api/backup' && req.method === 'POST') {
    try {
      backupData();
      sendJSON(res, 200, { ok: true });
    } catch (e) { sendJSON(res, 500, { error: e.message }); }
    return;
  }

  // Static
  let filePath;
  if (url === '/' || url === '/index.html') {
    filePath = path.join(PUBLIC_DIR, 'index.html');
  } else {
    filePath = path.join(PUBLIC_DIR, url);
    if (!filePath.startsWith(PUBLIC_DIR)) {
      res.writeHead(403); return res.end('Forbidden');
    }
  }
  serveStatic(res, filePath);
});

// Affichage au lancement
function getLocalIPs() {
  const nets = os.networkInterfaces();
  const ips = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) ips.push(net.address);
    }
  }
  return ips;
}

server.listen(PORT, '0.0.0.0', () => {
  console.log('\n==========================================');
  console.log('  inerWeb Eval EP3 — serveur démarré');
  console.log('==========================================\n');
  console.log(`  Ton PC         : http://localhost:${PORT}`);
  const ips = getLocalIPs();
  if (ips.length) {
    console.log(`  Autre prof     : http://${ips[0]}:${PORT}`);
    if (ips.length > 1) {
      console.log('  (autres IP)    : ' + ips.slice(1).map(ip => `http://${ip}:${PORT}`).join(' · '));
    }
  } else {
    console.log('  ⚠ Aucune IP locale détectée (pas de réseau ?)');
  }
  console.log(`\n  Données        : ${DATA_FILE}`);
  console.log(`  Backup auto    : toutes les heures dans data/backups/`);
  console.log('\n  Laisse cette fenêtre ouverte pendant la session.');
  console.log('  Ferme avec Ctrl+C quand tu as fini.\n');
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n❌ Port ${PORT} déjà utilisé. Ferme l'autre instance ou change le PORT en ligne 11.\n`);
  } else {
    console.error('\n❌ Erreur serveur :', err.message, '\n');
  }
  process.exit(1);
});

@echo off
title inerWeb Eval EP3 - serveur local
cd /d "%~dp0"
echo.
echo ================================================
echo   inerWeb Eval EP3 - demarrage du serveur
echo ================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
    echo [ERREUR] Node.js n'est pas installe ou pas dans le PATH.
    echo.
    echo Telecharge-le sur : https://nodejs.org
    echo Choisis la version LTS, installe avec les options par defaut.
    echo.
    pause
    exit /b 1
)

node server.js

echo.
echo ================================================
echo   Serveur arrete.
echo ================================================
pause

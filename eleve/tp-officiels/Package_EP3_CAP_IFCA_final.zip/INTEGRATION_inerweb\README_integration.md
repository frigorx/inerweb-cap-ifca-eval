# Intégration inerWeb TT-IA — Révisions EP3 CAP IFCA 2

**Date :** 2026-04-24
**Auteur :** F. Henninot
**Projet cible :** inerweb-tt-ia v7.8.2

## Contenu de ce dossier

Deux fichiers JSON formatés pour être **fusionnés** avec les fichiers existants de ton framework inerWeb :

| Fichier à ajouter | Destination dans inerweb | Contenu |
|---|---|---|
| `catalogue_additions_revisions_EP3.json` | `data/tp-library/catalogue.json` (array `tps`) | 6 nouveaux TP (TP-050 à TP-055) |
| `mappings_additions_revisions_EP3.json` | `data/tp-mappings/mappings.json` (array `mappings`) | 6 mappings CAP_IFCA · EP3 · Situation A |

## Correspondance TP inerWeb ↔ Fichiers HTML imprimables

| ID inerWeb | Titre court | Fichier HTML | Séance |
|---|---|---|---|
| TP-050 | Pose manifold + tirage au vide + fuite | `S1_27-04-2026/TP1A_Pose_manifold_tirage_vide.html` | Lun 27/04 |
| TP-051 | Remplacement + réglage pressostat BP | `S2_04-05-2026/TP1B_Remplacement_reglage_pressostat.html` | Lun 04/05 |
| TP-052 | Dépose + étanchéité + bon intervention | `S3_11-05-2026/TP1C_Depose_etancheite_remise_service.html` | Lun 11/05 |
| TP-053 | Mesures T° pures (6 points + ΔT) | `S1_27-04-2026/TP2A_Mesures_temperatures.html` | Lun 27/04 |
| TP-054 | Mesures P/T + SC/SR + Fiche MES | `S2_04-05-2026/TP2B_Mesures_PT_surchauffe_sous_refroidissement.html` | Lun 04/05 |
| TP-055 | Incondensables + TeqCO₂ + Plaque FGaz | `S3_11-05-2026/TP2C_Incondensables_revision_SC_SR.html` | Lun 11/05 |

## Méthode de fusion (au choix)

### Option A — Fusion manuelle (propre)

1. Ouvre `data/tp-library/catalogue.json` dans ton inerweb
2. Copie les 6 objets du champ `tps` de `catalogue_additions_revisions_EP3.json`
3. Colle-les dans le champ `tps` de `catalogue.json` (avant la fermeture `]`)
4. Même chose pour `mappings.json` avec le champ `mappings`
5. Mets à jour le `lastUpdate` du `_meta` (2026-04-24)

### Option B — Script PowerShell (automatique)

Je peux te faire un petit script PowerShell qui :
- charge les deux fichiers JSON (existant + additions)
- fusionne les arrays `tps` / `mappings`
- détecte les doublons par `id` / `tpId`
- sauvegarde les fichiers originaux (`.backup`)
- écrit les nouveaux fichiers

Dis-moi si tu veux que je te le produise.

## Conformité avec ton modèle

Les 6 TP respectent **strictement** le schéma documenté dans `docs/TP_LIBRARY_MODELE.md` :

- Tous les champs obligatoires : `id`, `titre`, `description`, `theme`, `duree`, `difficulte`, `type`, `materiel`, `operations`, `tags`, `auteur`, `version`, `statut`, `scope`
- Champs optionnels renseignés : `sousTitre`, `prerequisMateriels`, `variantes`, `remarquesPedago`, `observationsUsage`
- Un champ `contenuPedagogique` ajouté (non standard mais rétro-compatible) qui pointe vers le fichier HTML imprimable correspondant — tu peux l'ignorer si ton schéma ne le prévoit pas, ou l'utiliser pour lier les supports physiques.

Les 6 mappings respectent **strictement** `docs/TP_REFERENTIEL_MAPPINGS.md` :

- `tpId`, `formation` (CAP_IFCA), `annee` (2), `epreuve` (EP3)
- `competences` avec `code`, `niveauAttendu`, `contexte` (Situation A), `criteres` détaillés
- `sequencesSuggerees` (S2 — Mise en service avancée, cohérent avec ton référentiel)
- `dureeAdaptee` et `remarques`

## Compétences couvertes par les 6 TP

Selon ton `formations.json`, l'EP3 CAP IFCA Situation A mobilise : C4.1, C4.2, C4.3, C4.5, C4.6, C4.7, C5.1. En plus : C2.2 (sécurité) · C3.7 (remplacement composant) · C1.3 (documentation).

**Couverture des 6 TP :**

| Compétence | TP-050 | TP-051 | TP-052 | TP-053 | TP-054 | TP-055 |
|---|---|---|---|---|---|---|
| C1.3 | | | ✓ | | ✓ | ✓ |
| C2.2 | ✓ | ✓ | | ✓ | ✓ | |
| C3.7 | | ✓ | ✓ | | | |
| C4.1 | ✓ | | | | | |
| C4.2 | ✓ | | | | ✓ | ✓ |
| C4.3 | ✓ | ✓ | ✓ | | | |
| C4.5 | ✓ | | | ✓ | ✓ | |
| C4.6 | | ✓ | | | | |
| C4.7 | ✓ | | ✓ | | | |
| C5.1 | | | | ✓ | ✓ | ✓ |

Toutes les compétences EP3 sont donc couvertes au moins une fois à travers les 6 TP.

## Ce qui reste à faire (optionnel)

- Héberger les fichiers HTML imprimables (TP1A, TP1B, etc.) dans un endroit accessible depuis inerweb (par ex. `edu/resources/EP3/`), puis enrichir le champ `contenuPedagogique.fichier` avec le chemin relatif
- Produire des fichiers `eval-*.json` dans `data/eval/` si ton système EVAL attend des grilles d'évaluation séparées par TP
- Intégrer les 9 fiches Pascal Whart comme activités de type `"technologie"` ou `"remediation"` dans le catalogue (elles sont pour l'instant des fiches HTML indépendantes)
- Vérifier que la numérotation TP-050 à TP-055 ne rentre pas en conflit avec tes TP en cours d'ajout (si oui, décale)
